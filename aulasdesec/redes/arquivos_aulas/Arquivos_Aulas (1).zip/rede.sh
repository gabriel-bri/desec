#!/bin/bash
##read b1 b2 b3 b4
printf '%d'.'%d'.'%d'.'%d\n' 0x$1 0x$2 0x$3 0x$4
